package pages;

public class atm_Transaction {
	
	
	public void withamoun() {
		
		
		
		
	}
	
	public void checkbal() {
		
		
		
		
	}
	
	
	
	

	public static void main(String[] args) {
		
		
		int bal = 59000 , withdraw , depoditamont;
		
		int value =5000;
		//Scanner scan = new Scanner(System.in);
		switch(value ) {
		
		case 1:
			
			
			withdraw = 6700;
		
		if(bal >= withdraw) {
			
			
			bal= bal-withdraw;
			
			System.out.println(bal);
			
			
		}
		
		}
		
		
		
		

	}

}
